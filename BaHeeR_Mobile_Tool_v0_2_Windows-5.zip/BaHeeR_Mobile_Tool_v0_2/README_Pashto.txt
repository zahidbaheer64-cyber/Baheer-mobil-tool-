BaHeeR Mobile Tool v0.2 — د Windows لومړنۍ پرمختللې نسخه

څه پکې کار کوي:
- د Windows ډیسکتاپ پروګرام
- د ADB موجودیت معلومول
- د USB له لارې د ADB مجاز وسایلو پېژندنه (read-only)
- د رسمي Android Platform-Tools پاڼې پرانیستل
- د جوړونکو رسمي ملاتړ پاڼو ته تګ
- د عملیاتو محلي تاریخچه په SQLite کې ساتل
- د مشتریانو حسابونه او د پېژندپاڼو ذخیره نشته

چلول:
1) په Windows 10/11 کې Python 3.10+ نصب کړئ.
2) د Android رسمي SDK Platform-Tools نصب کړئ:
   https://developer.android.com/tools/releases/platform-tools
3) adb.exe او fastboot.exe د Windows PATH ته اضافه کړئ.
4) په دې فولډر کې CMD خلاص او دا ولیکئ:
   python BaHeeR_Mobile_Tool.py

EXE جوړول:
pip install pyinstaller
pyinstaller --noconfirm --onefile --windowed --name BaHeeR_Mobile_Tool BaHeeR_Mobile_Tool.py

محدودیتونه:
دا نسخه لا د ټولو برانډونو فلش انجن نه لري. د هر شرکت رسمي، لاسلیک شوی firmware
او مجاز خدمت-وسیلې جلا دي. دا پروګرام FRP/اکونټ قفل نه ماتوي، امنیتي قفلونه نه بایپاس کوي،
او د موبایل firmware نه لیکي. د واقعي فلش لپاره به د هر برانډ رسمي/مجاز پروسه جلا ورزیاتېږي.
