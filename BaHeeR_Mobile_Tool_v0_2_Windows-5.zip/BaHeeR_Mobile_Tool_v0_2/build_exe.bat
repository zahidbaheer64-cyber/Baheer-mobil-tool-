@echo off
python -m pip install --upgrade pyinstaller
pyinstaller --noconfirm --onefile --windowed --name BaHeeR_Mobile_Tool BaHeeR_Mobile_Tool.py
pause
