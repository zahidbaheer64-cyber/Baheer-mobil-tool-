import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3, subprocess, shutil, webbrowser
from pathlib import Path
from datetime import datetime

BASE = Path(__file__).resolve().parent
DB_FILE = BASE / "baheer_mobile_tool.db"

OFFICIAL_RESOURCES = {
    "Samsung": "https://www.samsung.com/us/support/",
    "Xiaomi / Redmi": "https://www.mi.com/global/support/",
    "Tecno": "https://www.tecno-mobile.com/support/",
    "Infinix": "https://www.infinixmobility.com/support",
    "OPPO": "https://support.oppo.com/",
    "vivo": "https://www.vivo.com/en/support",
    "Huawei": "https://consumer.huawei.com/en/support/",
    "itel": "https://www.itel-life.com/support",
}

def connect_db():
    con = sqlite3.connect(DB_FILE)
    con.execute("""CREATE TABLE IF NOT EXISTS logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        date TEXT, brand TEXT, model TEXT, serial TEXT,
        operation TEXT, result TEXT, notes TEXT
    )""")
    return con

class BaHeeRApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("BaHeeR Mobile Tool | v0.2")
        self.geometry("1120x740")
        self.minsize(920, 620)
        self.configure(bg="#101827")
        self.style = ttk.Style(self)
        try: self.style.theme_use("clam")
        except tk.TclError: pass
        self.style.configure("Treeview", rowheight=27, font=("Segoe UI", 9))
        self.style.configure("Treeview.Heading", font=("Segoe UI", 9, "bold"))
        self.build()
        self.refresh_history()
        self.check_tools()

    def build(self):
        head = tk.Frame(self, bg="#14243a", height=76); head.pack(fill="x")
        tk.Label(head, text="BaHeeR Mobile Tool", bg="#14243a", fg="white",
                 font=("Segoe UI", 22, "bold")).pack(side="left", padx=22, pady=16)
        tk.Label(head, text="WINDOWS • v0.2", bg="#14243a", fg="#9db5d0",
                 font=("Segoe UI", 10, "bold")).pack(side="right", padx=24)

        shell = tk.Frame(self, bg="#101827"); shell.pack(fill="both", expand=True, padx=16, pady=16)
        side = tk.Frame(shell, bg="#17263b", width=205); side.pack(side="left", fill="y", padx=(0, 14)); side.pack_propagate(False)
        tk.Label(side, text="MODULES", bg="#17263b", fg="#8fa9c6", font=("Segoe UI", 10, "bold")).pack(anchor="w", padx=16, pady=(18, 8))
        for label, fn in [
            ("Dashboard", self.refresh_history),
            ("USB device detection", self.detect_devices),
            ("ADB / Fastboot status", self.check_tools),
            ("Official support pages", self.open_support),
            ("Operation history", self.refresh_history),
        ]:
            tk.Button(side, text=label, command=fn, anchor="w", relief="flat",
                      bg="#17263b", fg="white", activebackground="#244363",
                      activeforeground="white", padx=16, pady=11,
                      font=("Segoe UI", 9)).pack(fill="x")

        main = tk.Frame(shell, bg="#101827"); main.pack(side="left", fill="both", expand=True)
        tk.Label(main, text="Device service workspace", bg="#101827", fg="white",
                 font=("Segoe UI", 19, "bold")).pack(anchor="w")
        tk.Label(main, text="Device detection, official support resources and local service records.",
                 bg="#101827", fg="#a9b8ca", font=("Segoe UI", 10)).pack(anchor="w", pady=(3, 13))

        status = tk.Frame(main, bg="#20344e"); status.pack(fill="x", pady=(0, 12))
        self.adb_status = tk.Label(status, text="ADB: checking…", bg="#20344e", fg="white", font=("Segoe UI", 10, "bold"), padx=14, pady=12)
        self.adb_status.pack(side="left")
        self.fastboot_status = tk.Label(status, text="Fastboot: checking…", bg="#20344e", fg="white", font=("Segoe UI", 10, "bold"), padx=14, pady=12)
        self.fastboot_status.pack(side="left")
        self.device_status = tk.Label(status, text="Devices: not checked", bg="#20344e", fg="#c5d6e8", font=("Segoe UI", 9), padx=14, pady=12)
        self.device_status.pack(side="right")

        device_box = tk.LabelFrame(main, text=" Connected device information ",
                                   bg="#17263b", fg="white", padx=12, pady=10)
        device_box.pack(fill="x", pady=(0, 12))
        self.device_text = tk.Text(device_box, height=5, bg="#0d1725", fg="#dce8f5",
                                   insertbackground="white", relief="flat", font=("Consolas", 9))
        self.device_text.pack(fill="x")
        self.device_text.insert("1.0", "Connect an Android phone with USB debugging enabled, then click Detect devices.\n"
                                        "This module only reads connection information; it does not unlock or modify the phone.")
        self.device_text.config(state="disabled")
        row = tk.Frame(device_box, bg="#17263b"); row.pack(fill="x", pady=(8, 0))
        tk.Button(row, text="Detect devices", command=self.detect_devices, bg="#1677d2", fg="white",
                  relief="flat", padx=16, pady=8).pack(side="left")
        tk.Button(row, text="Check ADB / Fastboot", command=self.check_tools, bg="#31445c", fg="white",
                  relief="flat", padx=16, pady=8).pack(side="left", padx=8)
        tk.Button(row, text="Open official Platform Tools page", command=lambda: webbrowser.open("https://developer.android.com/tools/releases/platform-tools"),
                  bg="#31445c", fg="white", relief="flat", padx=16, pady=8).pack(side="left")

        form = tk.LabelFrame(main, text=" Save service operation ",
                             bg="#17263b", fg="white", padx=12, pady=10)
        form.pack(fill="x", pady=(0, 12))
        self.brand = tk.StringVar(value="Samsung"); self.model = tk.StringVar()
        self.serial = tk.StringVar(); self.operation = tk.StringVar(value="Device information")
        self.result = tk.StringVar(value="Completed"); self.notes = tk.StringVar()
        fields = [
            ("Brand", self.brand, "combo", list(OFFICIAL_RESOURCES)),
            ("Model", self.model, "entry", None),
            ("Serial / IMEI (optional)", self.serial, "entry", None),
            ("Operation", self.operation, "combo", ["Device information", "Official firmware research", "Authorized firmware service", "Factory reset (owner-authorized)", "Recovery / update", "ADB diagnostics", "Fastboot diagnostics", "Backup / restore"]),
            ("Result", self.result, "combo", ["Completed", "Failed", "Pending"]),
        ]
        for i, (label, var, typ, vals) in enumerate(fields):
            r, c = divmod(i, 2)
            cell = tk.Frame(form, bg="#17263b"); cell.grid(row=r, column=c, sticky="ew", padx=6, pady=5)
            tk.Label(cell, text=label, bg="#17263b", fg="#c5d6e8", font=("Segoe UI", 9)).pack(anchor="w")
            w = ttk.Combobox(cell, textvariable=var, values=vals, state="readonly") if typ == "combo" else ttk.Entry(cell, textvariable=var)
            w.pack(fill="x", pady=(3, 0), ipady=4)
        form.columnconfigure(0, weight=1); form.columnconfigure(1, weight=1)
        tk.Label(form, text="Technical notes", bg="#17263b", fg="#c5d6e8", font=("Segoe UI", 9)).grid(row=3, column=0, sticky="w", padx=6, pady=(5,0))
        ttk.Entry(form, textvariable=self.notes).grid(row=4, column=0, columnspan=2, sticky="ew", padx=6, pady=(3,7), ipady=4)
        tk.Button(form, text="Save to history", command=self.save_log, bg="#1677d2", fg="white", relief="flat", padx=16, pady=8).grid(row=5, column=0, sticky="w", padx=6)

        hist = tk.LabelFrame(main, text=" Recent operation history ",
                             bg="#17263b", fg="white", padx=8, pady=8)
        hist.pack(fill="both", expand=True)
        cols = ("date", "brand", "model", "operation", "result")
        self.tree = ttk.Treeview(hist, columns=cols, show="headings", height=6)
        for col, title, width in [("date","Date / time",145),("brand","Brand",115),("model","Model",135),("operation","Operation",280),("result","Result",100)]:
            self.tree.heading(col, text=title); self.tree.column(col, width=width, anchor="w")
        self.tree.pack(fill="both", expand=True)
        tk.Label(self, text="No customer profiles or ID-document storage. Device modification is not performed by this prototype.",
                 bg="#101827", fg="#91a4ba", font=("Segoe UI", 8)).pack(fill="x", padx=18, pady=(0,8))

    def run_cmd(self, args):
        try:
            p = subprocess.run(args, capture_output=True, text=True, timeout=12, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            return p.stdout.strip(), p.stderr.strip(), p.returncode
        except Exception as e:
            return "", str(e), 1

    def check_tools(self):
        adb = shutil.which("adb")
        fb = shutil.which("fastboot")
        self.adb_status.config(text="ADB: " + ("available" if adb else "not installed / not in PATH"))
        self.fastboot_status.config(text="Fastboot: " + ("available" if fb else "not installed / not in PATH"))

    def detect_devices(self):
        adb = shutil.which("adb")
        if not adb:
            messagebox.showwarning("ADB not found", "Install official Android SDK Platform-Tools and add its folder to Windows PATH, then restart this app.")
            self.check_tools(); return
        out, err, code = self.run_cmd([adb, "devices", "-l"])
        self.device_text.config(state="normal"); self.device_text.delete("1.0", "end")
        self.device_text.insert("1.0", out if out else (err or "No output"))
        self.device_text.config(state="disabled")
        count = sum(1 for line in out.splitlines()[1:] if line.strip() and "\tdevice" in line)
        self.device_status.config(text=f"Ready devices: {count}")
        if count == 0:
            messagebox.showinfo("Device detection", "No authorized ADB device found. Check the USB cable and approve the USB debugging prompt on the phone.")

    def open_support(self):
        url = OFFICIAL_RESOURCES.get(self.brand.get(), "https://www.android.com/")
        webbrowser.open(url)

    def save_log(self):
        if not self.model.get().strip():
            messagebox.showwarning("Model required", "Enter the phone model before saving.")
            return
        with connect_db() as con:
            con.execute("INSERT INTO logs(date,brand,model,serial,operation,result,notes) VALUES(?,?,?,?,?,?,?)",
                (datetime.now().strftime("%Y-%m-%d %H:%M"), self.brand.get(), self.model.get().strip(),
                 self.serial.get().strip(), self.operation.get(), self.result.get(), self.notes.get().strip()))
        self.model.set(""); self.serial.set(""); self.notes.set("")
        self.refresh_history()
        messagebox.showinfo("Saved", "Service record saved locally.")

    def refresh_history(self):
        for item in self.tree.get_children(): self.tree.delete(item)
        with connect_db() as con:
            rows = con.execute("SELECT date,brand,model,operation,result FROM logs ORDER BY id DESC LIMIT 100").fetchall()
        for row in rows: self.tree.insert("", "end", values=row)

if __name__ == "__main__":
    connect_db().close()
    BaHeeRApp().mainloop()
